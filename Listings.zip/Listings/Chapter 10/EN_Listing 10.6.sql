-- Listing 10.6.sql
-- Example for abbreviations in SQLScript
SELECT * 
FROM colors sizes;

SELECT * 
FROM colors, sizes;
