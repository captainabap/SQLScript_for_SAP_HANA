-- Listing 10.7.sql
-- The same example without abbreviation

SELECT * 
FROM colors AS sizes;

SELECT * 
FROM colors CROSS JOIN sizes;
