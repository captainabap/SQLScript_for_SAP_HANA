-- Listing 2.4.sql
-- Example for the simple identifieres

SELECT id, 
       status,
       title
       FROM tasks;
