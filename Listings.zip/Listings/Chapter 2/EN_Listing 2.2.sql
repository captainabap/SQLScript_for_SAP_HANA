-- Listing 2.2.sql
-- Example for different formatting

SELECT col1,col2 FROM T1;
SELECT col1,
       col2
    FROM T1 ;
